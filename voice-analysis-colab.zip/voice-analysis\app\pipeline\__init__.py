"""Independent audio analysis stages."""
