"""Conservative, pitch-only pilot decisions with neutral descriptions."""

import math
from numbers import Real


def _finite_number(value, minimum=0, maximum=None):
    if isinstance(value, bool) or not isinstance(value, Real) or not math.isfinite(value):
        return None
    if value < minimum or (maximum is not None and value > maximum):
        return None
    return float(value)


def score(features, cfg):
    reasons = [error["code"] for error in features.get("errors", [])]
    descriptors = []
    speech = _finite_number(features.get("valid_speech_seconds"))
    coverage = _finite_number(features.get("f0_valid_coverage"), maximum=1)
    pitch_range = _finite_number(features.get("pitch_range_p10_p90_st"))
    phrase_sd = _finite_number(features.get("pitch_sd_st_phrase_median"))
    quality = features.get("audio_quality") or {}
    if speech is None:
        reasons.append("speech_duration_unavailable")
    elif speech < cfg.MIN_SPEECH_SECONDS:
        reasons.append("insufficient_speech_duration")
    if coverage is None or coverage < cfg.MIN_F0_COVERAGE:
        reasons.append("f0_coverage_insufficient")
    if pitch_range is None or phrase_sd is None:
        reasons.append("pitch_features_unavailable")
    jumps = _finite_number(features.get("octave_jump_count"))
    jump_rate = _finite_number(features.get("octave_jump_per_min"))
    if jumps is None or jump_rate is None or not jumps.is_integer():
        reasons.append("pitch_reliability_unavailable")
    elif jumps >= cfg.OCTAVE_REVIEW_MIN_COUNT and jump_rate > cfg.MAX_OCTAVE_JUMPS_PER_MIN:
        reasons.append("pitch_octave_jumps_high")
    clipping = _finite_number(quality.get("clipping_pct"), maximum=100)
    if clipping is None:
        reasons.append("clipping_measurement_unavailable")
    elif clipping > cfg.CLIP_REVIEW_PCT:
        reasons.append("clipping_high")
    for warning in features.get("warnings", []):
        if warning in ("channel_weak", "channel_antiphase", "multichannel_selected_by_rms", "asr_disabled"):
            reasons.append(warning)
    if quality.get("status") not in ("ok", "warning", "insufficient"):
        reasons.append("quality_unavailable")
    elif quality["status"] == "insufficient":
        reasons.append("insufficient_audio_quality")
    if cfg.MODE == "ekspresivitas":
        reasons.append("expressivity_not_calibrated")
    if pitch_range is not None and phrase_sd is not None:
        if (abs(pitch_range - cfg.MIN_PITCH_RANGE_ST) <= cfg.PITCH_RANGE_BORDER_ST or
                abs(phrase_sd - cfg.MIN_PITCH_SD_ST) <= cfg.PITCH_SD_BORDER_ST):
            reasons.append("pitch_near_pilot_threshold")
        descriptors.append(f"Rentang nada P10–P90 {pitch_range:.2f} semitone.")
        descriptors.append(f"Median variasi nada per proksi frasa {phrase_sd:.2f} semitone.")
    rate = _finite_number(features.get("articulation_rate_syl_per_s"))
    if rate is not None:
        descriptors.append(f"Kecepatan artikulasi terestimasi {rate:.2f} suku kata/detik.")
    pause_ratio = _finite_number(features.get("pause_ratio"), maximum=1)
    if pause_ratio is not None:
        descriptors.append(f"Jeda internal mencakup {pause_ratio * 100:.1f}% rentang tuturan.")
    if reasons:
        insufficient = {"audio_too_short", "no_audio_stream", "insufficient_speech_duration", "insufficient_audio_quality"}
        status = "bukti_belum_cukup" if insufficient.intersection(reasons) else "perlu_peninjauan"
        descriptors.append("Bukti belum cukup untuk keputusan biner." if status == "bukti_belum_cukup" else "Hasil memerlukan peninjauan pengukuran.")
        return {"status": status, "abstain_reason": ";".join(dict.fromkeys(reasons)),
                "intonation_item_passed": None, "descriptors": descriptors}
    passed = pitch_range >= cfg.MIN_PITCH_RANGE_ST and phrase_sd >= cfg.MIN_PITCH_SD_ST
    descriptors.append("Variasi nada memenuhi ambang uji pilot." if passed else "Variasi nada belum memenuhi ambang uji pilot.")
    return {"status": "dapat_dinilai", "abstain_reason": None,
            "intonation_item_passed": bool(passed), "descriptors": descriptors}
