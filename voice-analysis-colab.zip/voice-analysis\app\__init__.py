"""Local voice analysis prototype."""
