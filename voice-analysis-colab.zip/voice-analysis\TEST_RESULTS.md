# Verifikasi Fase 1 — 26 Oktober 2026

Lingkungan: Windows x64, Python 3.11.14 portabel, CPU; ffmpeg/ffprobe `9.0.2-essentials_build-www.gyan.dev`. Dependency langsung di `requirements.txt`, seluruh 41 paket yang terpasang di `requirements-lock.txt`. Lingkungan lokal `.venv`, tool unduhan `.runtime`, bobot ASR `.cache/models`.

## Hasil pytest

Perintah final (folder bin ffmpeg sudah ditambahkan ke PATH sesi):

```powershell
.\.venv\Scripts\python.exe -m pytest -q --basetemp=.runtime/pytest-run-final --tb=short
```

Hasil aktual: **66 passed, 1 warning in 3.02s**. Tidak ada failed, error, atau skipped pada run final. Warning berasal dari Silero yang memakai `importlib.resources.path` deprecated.

Cakupan: 28 kasus kata (termasuk tiga acceptance wajib), angka/singkatan, semitone, sinus datar/bermodulasi, gain, silence dan coverage, octave jump lintas segmen, definisi jeda dan tempo, SNR/clipping, channel anti-phase, null/abstain/scoring, kegagalan ASR termasuk generator lazy, kegagalan VAD, CLI missing file, batch dengan file rusak, serta decoder ffmpeg dan Silero ONNX asli.

Riwayat masalah yang ditemukan:

- Run pertama: **58 passed, 7 errors**, 1 warning. Semua 7 error terjadi pada setup fixture `tmp_path`: akses folder temporary pytest bawaan Windows ditolak. Mengarahkan `--basetemp` ke workspace menyelesaikannya.
- Run berikutnya: **65 passed, 1 warning**. Setelah menambahkan regresi error generator ASR, run final menjadi 66 tes lulus.
- Smoke test import ASR pertama gagal karena `pkg_resources` tidak tersedia pada setuptools terbaru. `setuptools==80.9.0` dipin; import/model load/inference berikutnya berhasil. Peringatan deprecation `pkg_resources` dari CTranslate2 tetap ada pada smoke test ASR.
- Pemeriksaan kompatibilitas dependency: **All installed packages are compatible**, 41 paket. `compileall app scripts` juga berhasil.

## F0 sintetis

Audio dibuat di memori, 16 kHz, durasi 8 detik, proksi frasa [0,4] dan [4,8]. Ini menguji pitch langsung, tidak menganggap sinus sebagai speech untuk VAD.

| Sinyal | Range P10–P90 (st) | Median SD per frasa (st) | Coverage |
|---|---:|---:|---:|
| Sinus datar 200 Hz | 1,66e-10 | 6,36e-11 | 1,0 |
| F0 180×2^(5×sin(2π×0,5×t)/12) Hz | 9,5099 | 3,5417 | 1,0 |

## Smoke test model ASR

Whisper small berhasil diunduh dan dimuat pada CPU int8 dari `Systran/faster-whisper-small`, revision `536b0662742c02347bc0e980a01041f333bce120`.

SHA256 `model.bin`: `3e305921506d8872816023e4c273e75d2419fb89b24da97b4fe7bce14170d671`.

Inferensi langsung pada audio nol 3 detik dengan segmen speech sengaja diberikan menghasilkan **"Terima kasih."** (2 kata). Ini demonstrasi halusinasi ASR, bukan transkrip benar atau validasi akurasi. Uji end-to-end berikutnya menunjukkan bahwa VAD dalam CLI melewati ASR ketika tidak ada speech.

## Contoh CLI aktual

Workspace awal hanya berisi dua dokumen Markdown, **tidak ada video contoh pelamar**. Video hitam/hening sintetis 3 detik dibuat di `.runtime/smoke/silence.mp4`, lalu dijalankan:

```powershell
.\.venv\Scripts\python.exe scripts/analyze_file.py .runtime/smoke/silence.mp4
```

Cuplikan hasil aktual; JSON lengkap disimpan di `.runtime/smoke/silence-result.json`:

```json
{
  "analysis_version": "0.3.0",
  "status": "bukti_belum_cukup",
  "abstain_reason": "insufficient_speech_duration;f0_coverage_insufficient;pitch_features_unavailable",
  "valid_speech_seconds": 0.0,
  "f0_valid_coverage": null,
  "pitch_range_p10_p90_st": null,
  "articulation_rate_syl_per_s": null,
  "intonation_item_passed": null,
  "shadow_mode": true,
  "errors": [],
  "module_status": {
    "extract": "ok",
    "vad": "ok",
    "quality": "ok",
    "pitch": "ok",
    "transcribe": "skipped",
    "syllable": "skipped",
    "tempo": "skipped"
  }
}
```

## Integritas dan batas verifikasi

SHA256 `fitur-intonasi.md` sebelum dan sesudah pekerjaan sama:

`F36EAF95C931477F064CBDBBB19118AE7C218124115217CA80DA95C54E7B0B7B`

Konsep tidak diubah. Rancangan teknis diperbarui dan riwayat revisinya ditambahkan. Tidak ada FastAPI, queue, Docker, database, SER atau integrasi GII yang dibuat.

Belum diuji pada pelamar nyata, belum mengukur WER/akurasi suku kata/filler atau bias logat/perangkat, dan belum mengkalibrasi ambang. Suku kata `mempertanggungjawabkan=8` adalah override acceptance yang didokumentasikan, bukan kaidah linguistik. Inferensi ASR belum memiliki hard timeout proses. Semua hasil tetap shadow mode.
